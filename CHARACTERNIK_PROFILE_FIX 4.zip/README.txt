Исправление профиля ГАРТ №001.
В файле index.html исправлены три обращения к таблице kh_profiles -> khar_profiles.
Загрузите index.html в корень github.com/Characternik/characternik с заменой текущего и нажмите Commit changes.
Адрес сайта: https://characternik.github.io/characternik/
Не загружайте секретные ключи.
